const express = require('express');
const mongoose = require('mongoose');
const WebSocket = require('ws');
const http = require('http');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/chatApp', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));

// Define a schema and model
const chatSchema = new mongoose.Schema({
  sender: String,
  content: String,
  timestamp: { type: Date, default: Date.now }
});

const Chat = mongoose.model('Chat', chatSchema);

// WebSocket connection handler
wss.on('connection', ws => {
  console.log('New WebSocket connection established');
  
  ws.on('message', async message => {
    try {
      const msg = JSON.parse(message);
      console.log('Received message:', msg);

      // Save message to MongoDB
      const savedMessage = await new Chat(msg).save();
      console.log('Message saved:', savedMessage);

      // Broadcast the message to all connected clients
      wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(msg));
        }
      });
    } catch (error) {
      console.error('Error saving message:', error);
    }
  });
});

// Start server
const port = 5000;
server.listen(port, () => {
  console.log(Server running on port ${port});
});